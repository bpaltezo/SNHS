<?php session_start(); ?>
<!DOCTYPE html>
<html>

<?php
    
    include "includes/functions.php";

?>

<head>
    
    <title>Blank Page | Bootstrap Based Admin Template - Material Design</title>
<?php include "includes/links.php"; ?>

</head>

<body class="theme-teal">

<?php include "includes/header.php"; ?>    

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>
        </div>
         <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                USER LOGS
                            </h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle btn bg-teal btn-circle-lg wave-effect waves-circle waves-float" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">print</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a class="table-to-pdf">Export as PDF</a></li>
                                        <li><a class="table-to-xls">Export as Excel</a></li>
                                        <li><a class="table-to-csv">Export as CSV</a></li>
                                        <li><hr></li>
                                        <li><a  class="table-to-copy">Copy</a></li>
                                        <li><a  class="table-to-print">Print</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable datatable-responsive">
                                    <thead>
                                        <tr>
                                        	<th>User</th>
                                            <th>Role</th>
                                            <th>Time In</th>
                                            <th>Time Out</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php echo LoadLogs(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="body" style="display: none;">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Role</th>
                                            <th>Time In</th>
                                            <th>Time Out</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php echo LoadLogs(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->
    </section>

</body>

<?php include "includes/footer.php"; ?>

</html>