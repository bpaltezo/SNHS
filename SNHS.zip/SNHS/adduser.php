<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
    
    <title>Blank Page | Bootstrap Based Admin Template - Material Design</title>
<?php include "includes/links.php";include "includes/functions.php"; ?>
</head>

<body class="theme-red">

<?php include "includes/header.php"; ?>    

    <section class="content">

        <div class="container-fluid">
            <div class="block-header">
                <h2>ADD NEW USER</h2>
            </div>
        </div>
        
        <?php

            $functionStatus = "";

            if(isset($_POST["new"]) && $_POST["type"] == "treasurer"){

                if(AddNewUser("treasurer", $_POST["uid"], $_POST["pwd"], $_POST["fname"], $_POST["address"], $_POST["contact"] )){
                    $functionStatus = "success";
                }

            }

            if(isset($_POST["new"]) && $_POST["type"] == "pro"){

                if(AddNewUser("pro", $_POST["uid"], $_POST["pwd"], $_POST["fname"], $_POST["address"], $_POST["contact"] )){
                    $functionStatus = "success";
                }

            }


            if(isset($_GET["treasurer"])){

                include "includes/users_add_treasurer.php";

            }else if(isset($_GET["pro"])){

                include "includes/users_add_pro.php";

            }

        ?>

    </section>

</body>
<?php include "includes/footer.php"; ?>
</html>

<script type="text/javascript">
    
    window.onload = function(){

        var postStatus = "<?php echo $functionStatus; ?>";

        if(postStatus == "success"){

            swal({
                title: "Success!",
                text: "A new user has added successfully",
                type: "success"
                }, function(isConfirm){
                    if(isConfirm){
                        window.location.href = "users.php";
                    }
            });

        }else{
            $("#tmodalbtn").click();
        }

    }

</script>