<?php session_start(); ?>
<!DOCTYPE html>
<html>

<?php
    
    include "includes/functions.php";
    
    if(isset($_POST["id"]) && isset($_POST["name"])){
        
        if(AddNewMember($_POST["id"], $_POST["name"],
                        $_POST["gs"], $_POST["guardian"],
                        $_POST["contact"], $_POST["address"])){

            echo CreateDialog("success", "A new member is successfully added!",
                              "members.php");

        }else{

            echo "<script>alert('Failed to add a member!');window.location.href = 'members.php';</script>";
        }

    }

?>

<head>
    
    <title>Blank Page | Bootstrap Based Admin Template - Material Design</title>
<?php include "includes/links.php"; ?>

</head>

<body class="theme-teal">

<?php include "includes/header.php"; ?>    

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                
            </div>
        </div>
         <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                STUDENT MASTERLIST
                            </h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle btn bg-blue btn-circle-lg wave-effect waves-circle waves-float" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons fa-3x">person_add</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a data-toggle="modal" data-target="#cmp">New Member</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle btn bg-teal btn-circle-lg wave-effect waves-circle waves-float" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">print</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a class="table-to-pdf">Export as PDF</a></li>
                                        <li><a class="table-to-xls">Export as Excel</a></li>
                                        <li><a class="table-to-csv">Export as CSV</a></li>
                                        <li><hr></li>
                                        <li><a  class="table-to-copy">Copy</a></li>
                                        <li><a  class="table-to-print">Print</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable datatable-responsive">
                                    <thead>
                                        <tr>
                                        	<th></th>
                                            <th>School ID</th>
                                            <th>Name</th>
                                            <th>Level</th>
                                            <th>Guardian</th>
                                            <th>Address</th>
                                        	<th>Contact</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php echo LoadMembers("all"); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="body" style="display: none;">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>School ID</th>
                                            <th>Name</th>
                                            <th>Level</th>
                                            <th>Guardian</th>
                                            <th>Address</th>
                                            <th>Contact</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php echo LoadMembers("exportable"); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->
    </section>

<!-- Large Size Modal -->
<div class="modal fade" id="cmp" tabindex="-1" role="dialog">
   	<div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="largeModalLabel">Add New Member</h4>
            </div>
            <form method="post" action="members.php">
            <div class="modal-body">
            <div class="container-fluid">
                <br>
            	<div class="row">
                    <div class="col-lg-6">
                        
                        <label>School ID</label>
                        <div class="input-group">
                            <div class="form-line">
                               <input type="text" name="id" class="form-control" autocomplete="off" required />
                            </div>
                        </div>
                        
                        <label>Name</label>
                        <div class="input-group">
                            <div class="form-line">
                               <input type="text" name="name" class="form-control" autocomplete="off" required>
                            </div>
                        </div>
                        
                        <label>Grade & Section</label>
                        <select class="form-control" name="gs" required>
                            <option></option>
                            <optgroup label="Grade 7">
                                <option value="7-A">7 - A</option>
                                <option value="7-B">7 - B</option>
                                <option value="7-C">7 - C</option>
                            </optgroup>
                            <optgroup label="Grade 8">
                                <option value="8-A">8 - A</option>
                                <option value="8-B">8 - B</option>
                                <option value="8-C">8 - C</option>
                            </optgroup>
                            <optgroup label="Grade 9">
                                <option value="9-A">9 - A</option>
                                <option value="9-B">9 - B</option>
                                <option value="9-C">9 - C</option>
                            </optgroup>
                            <optgroup label="Grade 10">
                                <option value="10-A">10 - A</option>
                                <option value="10-B">10 - B</option>
                                <option value="10-C">10 - C</option>
                            </optgroup>
                            <optgroup label="Grade 11">
                                <option value="11-A">11 - A</option>
                                <option value="11-B">11 - B</option>
                                <option value="11-C">11 - C</option>
                            </optgroup>
                            <optgroup label="Grade 12">
                                <option value="12-A">12 - A</option>
                                <option value="12-B">12 - B</option>
                                <option value="12-C">12 - C</option>
                            </optgroup>
                        </select>
                        
                    </div>
                    <div class="col-lg-6">

                        <label>Guardian</label>
                        <div class="input-group">
                            <div class="form-line">
                               <input type="text" name="guardian" class="form-control" autocomplete="off" required>
                            </div>
                        </div>
                        
                        <label>Contact</label>
                        <div class="demo-masked-input">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="material-icons">phone_iphone</i>
                            </span>
                            <div class="form-line">
                                <input type="text" name="contact" class="form-control mobile-phone-number" placeholder="+00 (000) 000-00-00">
                            </div>
                        </div>
                        </div>

                        <label>Address</label>
                        <div class="input-group">
                            <div class="form-line">
                               <input type="text" name="address" class="form-control" autocomplete="off" required>
                            </div>
                        </div>
                        
                    </div>          
            	</div>
            </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-link waves-effect">ADD</button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CANCEL</button>
            </div>
            </form>
        </div>
    </div>
</div>

</body>

<?php include "includes/footer.php"; ?>

</html>