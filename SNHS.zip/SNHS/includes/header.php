<!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
<!-- #END# Page Loader -->
<!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
<!-- Top Bar -->
    <nav class="navbar" style="background:teal;">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="./">SUAL NHS - PTA Fee Monitoring and Event Dissemination System </a>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                   
                    <!-- Notifications -->
                    <?php 
                    include "functions/loadnotificationbellcontent.php";
                    $count = $notifications["events"]["count"];
                    $cclass = ($count > 0) ? "bg-pink" : "";
                    ?>
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                            <i class="material-icons">notifications</i>
                            <span class="label-count <?php echo $cclass; ?>">
                                <?php if($count > 0) echo $count; ?>
                            </span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">NOTIFICATIONS</li>
                            <li class="body">
                                <ul class="menu">
                                    <?php echo $notifications["events"]["content"]; ?>
                                </ul>
                            </li>
                            <li class="footer">
                                <a href="javascript:void(0);">View All Notifications</a>
                            </li>
                        </ul>
                    </li>
                    <!-- #END# Notifications -->
                    <li class="pull-right"><a href="javascript:void(0);" class="js-right-sidebar" data-close="true"><i class="material-icons">more_vert</i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- #Top Bar -->
<section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="images/logo.ico" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo ucwords($_SESSION["user"]); ?>
                    </div>
                    <div class="email"></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li role="separator" class="divider"></li>
                            <li><a href="logout.php"><i class="material-icons">input</i>Sign Out</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header"></li>
                    <li>
                        <a href="./">
                            <i class="material-icons">dashboard</i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                     <?php

                        if($_SESSION["usertype"] == "administrator"){
                            echo '<li>
                        <a href="#" class="menu-toggle">
                            <i class="material-icons">account_circle</i>
                            <span>Users</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="users.php">
                                    <span>All Users</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="menu-toggle">
                                    <span>Add New</span>
                                </a>
                                <ul class="ml-menu">
                                    <li>
                                        <a href="adduser.php?treasurer">Treasurer</a>
                                    </li>
                                    <li>
                                        <a href="adduser.php?pro">P.R.O.</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>';
                        }

                    ?>
                    <?php

                        if($_SESSION["usertype"] == "pro" || $_SESSION["usertype"] == "administrator"){
                            echo '<li>
                        <a href="events.php">
                            <i class="material-icons">insert_invitation</i>
                            <span>Events</span>
                        </a>
                    </li><li>
                        <a href="members.php">
                            <i class="material-icons">people_outline</i>
                            <span>Members</span>
                        </a>
                    </li>';
                        }
                    ?>
                    
                    <?php

                        if($_SESSION["usertype"] == "treasurer" || $_SESSION["usertype"] == "administrator"){
                            echo '<li>
                        <a href="monitoring.php">
                            <i class="material-icons">assignment</i>
                            <span>Fee Monitoring</span>
                        </a>
                    </li>';
                        }

                    ?>

                    <?php

                        if($_SESSION["usertype"] == "administrator" || $_SESSION["usertype"] == "pro"){
                            echo '<li>
                        <a href="archive.php">
                            <i class="material-icons">archive</i>
                            <span>Archive</span>
                        </a>
                    </li>
                     <li>
                        <a href="logs.php">
                            <i class="material-icons">history</i>
                            <span>Logs</span>
                        </a>
                    </li>';
                        }

                    ?>
                    <li>
                        <a href="logout.php">
                            <i class="material-icons">settings_power</i>
                            <span>Log Out</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; <?php echo date("Y", strtotime("-1 year"))." - ".date("Y"); ?> 
                    <a href="javascript:void(0);">SNHS - PTA SUITE</a>.
                </div>
                
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        <aside id="rightsidebar" class="right-sidebar">
            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                <li role="presentation" class="active"><a href="#settings" data-toggle="tab">CONNECTION</a></li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade active in" id="settings">
                    <div class="demo-settings">
                        <p>GENERAL SETTINGS</p>
                        <ul class="setting-list">
                            <li>
                                <span>Connect Automatically</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <b>Status: </b><span>
        <?php 
            if(!$sock = @fsockopen('www.google.com', 80)){
                echo 'Not Connected';
            }else{
                echo 'Connected';
            } 
        ?></span>
                            </li>
                        </ul>
                        
                    </div>
                </div>
            </div>
        </aside>
        <!-- #END# Right Sidebar -->
    </section>