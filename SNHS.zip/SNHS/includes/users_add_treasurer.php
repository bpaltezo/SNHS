<!-- Default Size -->
<button data-toggle="modal" data-target="#tmodal" id="tmodalbtn" style="display: none;">
</button>
<div class="modal show" id="tmodal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <form method="post" action="adduser.php">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">New Treasurer Account</h4>
            </div>
            <div class="modal-body">
                <input type="hidden" name="new">
                <input type="hidden" name="type" value="treasurer">
                <br>
                <div class="row">
                <div class="col-lg-12">
                    <div class="form-group form-float">
                        <div class="form-line">
                            <input type="text" class="form-control" name="uid" autocomplete="off" required>
                            <label class="form-label">Username</label>
                        </div>
                    </div>
                    <div class="form-group form-float">
                        <div class="form-line">
                            <input type="password" class="form-control" name="pwd" required>
                            <label class="form-label">Password</label>
                        </div>
                    </div>
                    <label>Additional Informations</label>
                    <br><br>
                    <div class="form-group form-float">
                        <div class="form-line">
                            <input type="text" class="form-control" name="fname" autocomplete="off">
                            <label class="form-label">Full Name</label>
                        </div>
                    </div>
                    <div class="form-group form-float">
                        <div class="form-line">
                            <input type="text" class="form-control" name="address" autocomplete="off">
                            <label class="form-label">Address</label>
                        </div>
                    </div>
                    <div class="form-group form-float">
                        <div class="form-line">
                            <input type="number" class="form-control" name="contact" autocomplete="off">
                            <label class="form-label">Contact</label>
                        </div>
                    </div>
                </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-link waves-effect">SUBMIT</button>
                <a href="users.php" class="btn btn-link waves-effect">CANCEL</a>
            </div>
        </div>
        </form>
    </div>
</div>
<script type="text/javascript">
    
    window.onload = function(){

        $("#tmodalbtn").click();

    }

</script>