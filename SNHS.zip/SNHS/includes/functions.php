<?php

	function NewSession($type, $id, $user, $pwd, $name, $address, $contact){

		$_SESSION["usertype"] = $type;
		$_SESSION["userid"] = $id;
		$_SESSION["user"] = $user;
		$_SESSION["pwd"] = $pwd;
		$_SESSION["userfullname"] = $name;
		$_SESSION["useraddress"] = $address;
		$_SESSION["usercontact"] = $contact;

		if(isset($_SESSION['user']) && isset($_SESSION['pwd'])) return true;
		else return false;
	
	}

	function TrueOrFalse($value){
		if($value){
			return true;
		}else{
			return false;
		}
	}

	function time_elapsed_string($datetime, $full = false) {

		date_default_timezone_set("Asia/Manila");

    	$now = new DateTime;
    	$ago = new DateTime($datetime);
    	$diff = $now->diff($ago);

    	$diff->w = floor($diff->d / 7);
    	$diff->d -= $diff->w * 7;

    	$string = array(
        	'y' => 'year',
        	'm' => 'month',
        	'w' => 'week',
        	'd' => 'day',
        	'h' => 'hour',
        	'i' => 'minute',
        	's' => 'second',
    	);
    	foreach ($string as $k => &$v) {
        	if ($diff->$k) {
            	$v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        	} else {
            	unset($string[$k]);
        	}
    	}

    	if (!$full) $string = array_slice($string, 0, 1);
    	return $string ? implode(', ', $string) . ' ago' : 'just now';
	}

	
	function dateDifference($date, $differenceFormat = '%a' ){
    	$now = date_create(date("Y-m-d"));
    	$datetime = date_create($date);
    	$interval = date_diff($now, $datetime);
    	return ($interval->format($differenceFormat) > 0)
    			? ($interval->format($differenceFormat) > 0)." Days to go"
    			: "Today";
    }

    function ValidAccount($uid, $pwd){

    	$conn = mysqli_connect("localhost", "root", "", "pta");
    	$sql = "SELECT * FROM users WHERE uid='$uid' AND pwd='$pwd'";
    	$res = $conn->query($sql);
    	$result = array();
    	$result[0] = false;
    	while($row = $res->fetch_assoc()){

    		if($row["status"] == 1){
    			$result[1] = "disabled";
    		}else{
    			$result[0] = true;
    			$result[1] = $row['type'];
    			$result[2] = $row['id'];
    			$result[3] = $row['name'];
    			$result[4] = $row['address'];
    			$result[5] = $row['contact'];
    		}

    	}
    	return $result;
    }

    function Logs($type, $id){

    	date_default_timezone_set("Asia/Manila");
    	$conn = mysqli_connect("localhost", "root", "", "pta");

    	$time = date("M d Y h:i:s a");

    	if($type == "login"){
    		
    		$sql = "INSERT INTO logs (userid, timein) VALUES ('$id', '$time')";
    		$_SESSION["logintime"] = $time;
    		$_SESSION["loginid"] = $id;

    	}else if($type == "logout"){

    		$timein = $_SESSION["logintime"];
    		$loginid = $_SESSION["loginid"];
    		$sql = "UPDATE logs SET logout='$time' 
    				WHERE timein = '$timein' AND userid = '$loginid' ";
    		$_SESSION["logintime"] = $time;

    	}
		
		$res = $conn->query($sql);
		return TrueOrFalse($res);

    }

    function LoadLogs(){

    	$conn = mysqli_connect("localhost", "root", "", "pta");

    	$sql = "SELECT * FROM logs WHERE seen = 0";
    	$res = $conn->query($sql);
   	 	$result = "";

    	while($row = $res->fetch_assoc()){

        $sql2 = "SELECT * FROM users WHERE id = ".$row['userid'];
        $res2 = $conn->query($sql2);
        $name = "";
        $type = "";

        while($row2 = $res2->fetch_assoc()){
            $name = $row2["uid"];
            $type = $row2["type"];
        }

        $logintime = ($row["timein"] != "" ? time_elapsed_string($row["timein"]) : "");
        $logouttime = ($row["logout"] != "" ? time_elapsed_string($row["logout"]) : "");

        $result .= "<tr>";
        $result .= "<td>".$name."</td>";
        $result .= "<td>".ucfirst($type)."</td>";
        $result .= "<td>".$logintime."</td>";
        $result .= "<td>".$logouttime."</td>";
        $result .= "</tr>";
    	
    	}

    	return $result;

    }

	function LoadPayments(){

		$conn = mysqli_connect("localhost", "root", "", "pta");

		$sql = "SELECT * FROM payments";
		$res = $conn->query($sql);

		$payments = array();

		while ($row = $res->fetch_assoc()) {
			$payments[] = $row["monthly"];
			$payments[] = $row["homeroom"];
			$payments[] = $row["general"];
		}

		return $payments;

	}

	function UpdateAccount($id, $pos, $fee, $bal){

		$conn = mysqli_connect("localhost", "root", "", "pta");

		if($pos == 1){
			$sql = "UPDATE members SET payment_1 = '$fee', balance = '$bal'
			WHERE id = '$id' ";
		}else if($pos == 2){
			$sql = "UPDATE members SET payment_2 = '$fee', balance = '$bal'  
			WHERE id = '$id' ";
		}else if($pos == 3){
			$sql = "UPDATE members SET payment_3 = '$fee', balance = '$bal' 
			WHERE id = '$id' ";
		}
		
		$res = $conn->query($sql);

		return TrueOrFalse($res);

	}

	function AddNewUser($type, $uid, $pwd, $name, $address, $contact){

		$conn = mysqli_connect("localhost", "root", "", "pta");

		$sql = "INSERT INTO users (uid, pwd, type, name, address, contact) 
				VALUES ('$uid', '$pwd', '$type', '$name', '$address', '$contact')";
		$res = $conn->query($sql);

		return TrueOrFalse($res);

	}

	function LoadUsers(){

		$conn = mysqli_connect("localhost", "root", "", "pta");
		
		$sql = "SELECT * FROM users WHERE type != 'administrator'";
		$res = $conn->query($sql);

		$result = "";

		while($row = $res->fetch_assoc()){

			$pwdstar = "";

			for($i =0; $i < strlen($row['pwd']); $i++){
				$pwdstar .= "*";
			}

			$result .= "<tr scope='row'>";
			$result .= "<td></td>";
			$result .= "<td>".strtoupper($row['type'])."</td>";
			$result .= "<td>".$row['uid']."</td>";
			$result .= "<td>".crypt($row['pwd'])."</td>";

			if($row["status"] == 0){
				$result .= "<td><span class='badge bg-cyan'>Active</span></td>";
				$result .= '<td>
                            <a href="functions/disableaccount.php?id='.$row['id'].'" class="btn btn-primary">
                                <i class="material-icons">https</i> 
                                <span class="icon-name">DISABLE</span>
                            </a>
                        </td>';
			}else if($row["status"] == 1){
				$result .= "<td><span class='badge bg-pink'>Disabled</span></td>";
				$result .= '<td>
                            <a href="functions/enableaccount.php?id='.$row['id'].'" class="btn btn-success">
                                <i class="material-icons">lock_open</i> 
                                <span class="icon-name">ENABLE</span>
                            </a>
                            <a href="functions/removeaccount.php?id='.$row['id'].'" class="btn btn-danger">
                                <i class="material-icons">delete</i> 
                                <span class="icon-name">REMOVE</span>
                            </a>
                        </td>';
			}
			
			$result .= "</tr>";
		}

		return $result;
	}

	function AddNewMember($id, $name, $gradesec, $guardian, $contact, $address){

		$conn = mysqli_connect("localhost", "root", "", "pta");

		$payments = LoadPayments();
		$balance = intval($payments[0]) + intval($payments[1]) + intval($payments[2]);

		$sql = "INSERT INTO members (studid, name, gs, guardian, address, contact, payment_1, payment_2, payment_3, balance) VALUES ('$id', '$name', '$gradesec', '$guardian', '$address', '$contact', '$payments[0]', '$payments[1]', '$payments[2]', '$balance')";
		$res = $conn->query($sql);

		return TrueOrFalse($res);

	}

	function RemoveMember($id){

		$conn = mysqli_connect("localhost", "root", "", "pta");

		$sql = "UPDATE members SET deleted = 1 WHERE id = '$id' ";
		$res = $conn->query($sql);

		return TrueOrFalse($res);

	}

	function LoadMembers($condition="", $sms=false){

		$conn = mysqli_connect("localhost", "root", "", "pta");
		$sql = "SELECT * FROM members WHERE deleted = 0 ";
		$res = $conn->query($sql);
		$result = "";

	if($condition == "all"){
		
		$counter = 0;
		$notifbtn = "";

		while($row = $res->fetch_assoc()){

			$contact = str_replace(" ", "", $row["contact"]);
			$contact = str_replace("(", "", $contact);
			$contact = str_replace(")", "", $contact);
			$contact = str_replace("-", "", $contact);

			$name = str_replace(" ", "_", $row["name"]);

			$data = array();
			$data[] = $row["studid"];
			$data[] = $row["gs"];
			$data[] = $contact;
			$data[] = $name;
			$data[] = $row["payment_1"];
			$data[] = $row["payment_2"];
			$data[] = $row["payment_3"];
			$data[] = $row["balance"];
			$data[] = $row["id"];

			if($sms){
				$result .= '<tr class="std">
                            <td>
                                <input type="checkbox" data-number="'.$contact.'" class="chk" id="chk_'.$counter.'" />
                                <label for="chk_'.$counter.'"></label>
                            </td>';
            }else{
				$result .= '<tr><td></td><td>'.$row["studid"].'</td>';
			}

            $result .=  '<td>'.$row["name"].'</td>
                            <td>'.$row["gs"].'</td>
                            <td>'.$row["guardian"].'</td>';

            if(!$sms){
            	$result .= '<td>'.$row["address"].'</td><td>'.$contact.'</td>';
            }
			
            if($sms){
            	
            	if($row['balance'] <= 0){
            		$result .= '<td>'.$contact.'</td><td><center><span class="badge bg-cyan">PAID</span></center></td>';
            		$notifbtn = "disabled";
            	}else{
            		$result .= '<td>'.$contact.'</td><td><center><span class="badge bg-red">INC</span></center></td>';
            		$notifbtn = "";
            	}

            	$result .= '<td>&#8369; '.$row['balance'].'</td>';
            	
            	$result .= 	'<td>
                                <button class="btn bg-teal btn-xs waves-effect mngbtn" data-toggle="tooltip" data-placement="left" title="Update account" data-as="act" 
                                	data-rawdata='.json_encode($data).' >
                                    <i class="material-icons">account_box</i>
                                    <span class="icon-name"> Manage</span>
                                </button>
                            </td>';
            }else{
            	$result .= '<td>
            					<div class="js-sweetalert">
                                <button class="btn btn-danger waves-effect" data-type="confirm" data-title="Confirm Delete" data-content="Are you sure you want to remove this account?" data-target="'.$row["id"].'" data-location="members.php">
                                    <i class="material-icons">archive</i>
                                </button>
                                </div>
                            </td>';
            }

			$result .= '</tr>';

			$counter++;

		}

	}else if($condition == "exportable"){

		while($row = $res->fetch_assoc()){

			$result .= '<tr><td>'.$row["studid"].'</td><td>'.$row["name"].'</td><td>'.$row["gs"].'</td><td>'.$row["guardian"].'</td><td>'.$row["address"].'</td><td>'.$row["contact"].'</td></tr>';

		}


	}else if($condition == "archive" || $condition == "exportable archive"){

		$sql = "SELECT * FROM members WHERE deleted = 1";
		$res = $conn->query($sql);

		while($row = $res->fetch_assoc()){

			$result .= '<tr><td>'.$row["studid"].'</td><td>'.$row["name"].'</td><td>'.$row["gs"].'</td><td>'.$row["guardian"].'</td><td>'.$row["address"].'</td><td>'.$row["contact"].'</td><td>&#8369;'.$row['payment_1'].'</td><td>&#8369; '.$row['payment_2'].'</td><td>&#8369; '.$row['payment_3'].'</td><td>&#8369; '.$row['balance'].'</td></tr>';
		
		}

	}

		return $result;

	}

	function ExportableTable($condition = ""){

		$conn = mysqli_connect("localhost", "root", "", "pta");

		if($condition == "all"){
			$sql = "SELECT * FROM members WHERE deleted = 0 ";	
		}

		$res = $conn->query($sql);

		$result = "";

		while($row = $res->fetch_assoc()){
			$result .= '<tr>';
			$result .= '<td>'.$row["name"].'</td>';
			$result .= '<td>'.$row["gs"].'</td>';
			$result .= '<td>'.$row["guardian"].'</td>';
			$result .= '<td>'.$row["address"].'</td>';
			$result .= '<td>'.$row["contact"].'</td>';
			$result .= '<td>&#8369; '.$row["balance"].'</td>';
			$result .= '</tr>';
		}

		return $result;

	}

	function Payments($action="", $fee1="", $fee2="", $fee3="", $updateall=false){

		$conn = mysqli_connect("localhost", "root", "", "pta");

		$result = "";

		if($action == "load"){

			$sql = "SELECT * FROM payments";
			$res = $conn->query($sql);

			while($row = $res->fetch_assoc()){
				$result .= '<tr><td>&#8369; '.$row["monthly"].
							'</td><td>&#8369; '.$row["homeroom"].
							'</td><td>&#8369; '.$row["general"].'</td><td>'.time_elapsed_string($row["update_date"]).'</td></tr>';
			}
			return $result;
		
		}else if($action == "update"){

			if($fee1 != "" && $fee2 != "" && $fee3 != ""){

				date_default_timezone_set("Asia/Manila");
				$dt = date("D d M Y h:i:s a");

				$sql = "UPDATE payments SET monthly='$fee1', homeroom='$fee2', general='$fee3', update_date='$dt' WHERE id=1 ";
				$res = $conn->query($sql);

				if($updateall){

					if(UpdateMemberPayments($fee1, $fee2, $fee3) && $res){
						return true;
					}else{
						return false;
					}
					
				}

			}

		}

	}

	function UpdateMemberPayments($a, $b, $c){

		$conn = mysqli_connect("localhost", "root", "", "pta");
		$sql = "SELECT * FROM members";
		$res = $conn->query($sql);
		$result = false;
		while($row = $res->fetch_assoc()){

			$a = $a + $row["payment_1"];
			$b = $b + $row["payment_2"];
			$c = $c + $row["payment_3"];
			$total = $a + $b + $c;

			$sql2 = "UPDATE members SET payment_1='$a',
					payment_2='$b', payment_3='$c', balance='$total' 
					WHERE studid=".$row["studid"];
			$res2 = $conn->query($sql2);
			$result = true;
		}

		return $result;

	}

	function CreateDialog($type, $content, $location=""){

		if($type == "success"){
			echo '<div style="display:none;" class="js-sweetalert"><button class="btn btn-primary waves-effect" data-type="success" data-title="Success!" data-content="'.$content.'" data-location="'.$location.'" id="alertBtn"></button></div><script>window.onload = function(){document.getElementById("alertBtn").click();}</script>';
		}

	}

?>
