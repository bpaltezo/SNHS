<?php

	session_start();

	include "includes/functions.php";

	Logs("logout", "");

	session_destroy();
	header("Location: login.php");

?>