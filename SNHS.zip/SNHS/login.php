<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
    <title>Log In | Bootstrap Based Admin Template - Material Design</title>
<?php include "includes/links.php";include "includes/functions.php"; ?>
</head>

<body class="login-page">
    <div class="login-box">
        <div class="logo">
            <a href="javascript:void(0);">Sual NHS<b></b></a>
            <small>PTA Fee Monitoring and Event Dissemination System </small>
        </div>
        <div class="card">
            <div class="body">
                <form action="login.php" method="POST">
<?php

    $msgcontent = "";

    if(isset($_POST['username']) && isset($_POST['password'])){

        $account = ValidAccount($_POST['username'], $_POST['password']);

        if($account[0]){

            if(NewSession($account[1], $account[2], $_POST['username'], $_POST['password'], $account[3],$account[4],$account[5])){
            
                if($account[1] != "administrator"){
                    Logs("login", $account[2]);
                }

                header("Location: ./");
            
            }

        }else{
            $msgcontent = "<span class='alert bg-red alert-dismissible'>The password you entered is incorrect</span>";
        }

    }else{
        $msgcontent = "Log in to start your session";
    }

    
    //if(isset($_POST['password']) && isset($_POST['type'])){
    //    if($_POST['type'] == "Administrator" && $_POST['password'] == "admin12345"){
            
    //        if(NewSession($_POST['type'], $_POST['password'])){
    //            header("Location: ./");
    //        }
                  
    //    }else if($_POST['type'] == "Treasurer" && $_POST['password'] == "treasurer12345"){
            
    //        if(NewSession($_POST['type'], $_POST['password'])){
    //            header("Location: ./");    
    //        }
                  
    //    }else if($_POST['type'] == "P.R.O." && $_POST['password'] == "pro12345"){
            
    //        if(NewSession($_POST['type'], $_POST['password'])){
    //            header("Location: ./");
    //        }
                 
    //    }else{
    //        $msgcontent = "<span class='alert bg-red alert-dismissible'>The password you entered is incorrect</span>";
    //    }
    //}else{
    //    $msgcontent = "Log in to start your session";
    //}

?>
                    <br>
                    <div class="msg warning"><?php echo $msgcontent; ?></div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">perm_identity</i>
                        </span>
                        <div class="form-line">
                            <input type="text" class="form-control" name="username" placeholder="Username" required autocomplete="off">
                        </div>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" name="password" placeholder="Password" required autocomplete="off">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-8 p-t-5"></div>
                        <div class="col-xs-4">
                            <button class="btn btn-block bg-pink waves-effect" type="submit">SIGN IN</button>
                        </div>
                    </div>
                    <div class="row m-t-15 m-b--20"></div>
                </form>
            </div>
        </div>
    </div>

<?php include "includes/footer.php"; ?>
</body>

</html>