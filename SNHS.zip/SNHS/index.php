<?php session_start(); ?>
<?php
	if(!isset($_SESSION["user"])){
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>

<head>
    
    <title>PTA Suite | Sual National High School - PTA Fee Monitoring and Event Dissimination System</title>
<?php include "includes/links.php"; ?>
</head>

<body class="theme-red">

<?php include "includes/header.php"; ?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>WELCOME</h2>
            </div>

            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="body">
                            <?php
                                
                                $events = EventsToday();
                                
                                if(count($events)){

                                    for($i=0;$i<count($events);$i++){

                                        echo '<div class="alert alert-warning alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                Today is the '.$events[$i]['title'].'. The event will start at '.$events[$i]['time'].'
                                    </div>';

                                    }

                                }else{
                                    echo '<div class="alert alert-info alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                    There are no events for Today
                                    </div>';
                                }

                            ?>
                           
                        </div>
                    </div>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header"><h2>SMS FEATURE DETAILS</h2></div>
                        <div class="body">
                            <p><b>Provider: </b> <a target="_blank" href="https://­semaphore.co/­account#settings"> Semaphore.co</a></p>
                            <p><b>API Key: </b> 742afa72f86bb473bddb4aacc652190d</p>
                            <p><b>Credits: </b> <span id="smscredits"></span></p>
                            <br>
                            <p><b>Email: </b> gelinedelacruz87@gma­il.com</p>
                            <p><b>Password: </b> <span id="smspass" data-face="hidden">**************</span></p>
                            <button class="btn btn-default eyebtn">
                                <i class="material-icons">visibility</i>
                                Show Password
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

</body>
<?php include "includes/footer.php"; ?>
</html>

<script type="text/javascript">
    
    window.onload = function(){

        $(".eyebtn").on("click", function(){

            if($("#smspass").html().includes("*")){
            $(".eyebtn").html('<i class="material-icons">visibility_off</i> <span class="icon-name"> Hide Password</span>');
                $("#smspass").html("KINGandqueen87");
            }else{
                $(".eyebtn").html('<i class="material-icons">visibility</i> <span class="icon-name"> Show Password</span>');
                $("#smspass").html("**************");
            }

            console.log($("#smspass").data("face"));

        });
        
        /*
        $.ajax("https://api.semaphore.co/api/v4/account", {apikey: "742afa72f86bb473bddb4aacc652190d"}, function(data){
            console.log(data);
        });*/

        $.ajax({
            url: "https://api.semaphore.co/api/v4/account",
            data: {apikey: "742afa72f86bb473bddb4aacc652190d"},
            dataType: "json",
            success: function(data){
                console.log(data);
            }
        });

    }

</script>