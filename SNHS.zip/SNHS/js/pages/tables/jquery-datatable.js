$(function () {
    $('.js-basic-example').DataTable({
        responsive: true
    });

    //Exportable table
    $('.datatable-responsive').DataTable({
        dom: 'Bfrtip',
        responsive: true,
        buttons: []
    });

    //Exportable table
    $('.js-exportable').DataTable({
        dom: 'Bfrtip',
        responsive: true,
        buttons: [
            'excel', 'pdf', 'print', 'csv', 'copy'
        ]
    });

    $('.table-to-print').on("click", function(){
        $(".buttons-print").click();
    });

    $('.table-to-pdf').on("click", function(){
        $(".buttons-pdf").click();
    });

    $('.table-to-xls').on("click", function(){
        $(".buttons-excel").click();
    });

    $('.table-to-csv').on("click", function(){
        $(".buttons-csv").click();
    });

    $('.table-to-copy').on("click", function(){
        $(".buttons-copy").click();
    });

});

