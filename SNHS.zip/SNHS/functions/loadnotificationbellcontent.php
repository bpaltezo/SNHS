<?php

	function EventsToday(){

		$conn = mysqli_connect("localhost", "root", "", "pta");

		$today = date("Y-m-d");
		$sql = "SELECT * FROM events WHERE dt = '$today' ";
		$res = $conn->query($sql);
			
		$events = array();

		while($row = $res->fetch_assoc()){

			$event = array('id' => $row['id'], 'title' => $row['title'],
								'dt' => $row['dt'], 'time' => $row['startat'],
								'venue' => $row['venue'], 'seen' => $row['seen'], );
			$events[] = $event;
		}

		return $events;

	}

	function LoadNotifications(){

		$events = EventsToday();

		$notifications = array("events" => array("content" => '', "count" => 0));

		if(count($events) > 0){

			$notifications["events"]["count"] = count($events);

			for($x = 0;$x < count($events);$x++){

				$notifications["events"]["content"] .= '<li>
                                <a href="events.php" class="notifbell">
                                    <div class="icon-circle bg-teal">
                                        <i class="material-icons">event_available</i>
                                    </div>
                                    <div class="menu-info">
                                        <h4>'.$events[$x]["title"].'</h4>
                                        <p>
                                            <i class="material-icons">access_time</i> Starts at '.$events[$x]["time"].' today
                                        </p>
                                    </div>
                                </a>
                            </li>';
            }

		}else{
			$notifications["events"]["content"] ="<center>No scheduled events today</center>";
		}

		return $notifications;
	}

	$notifications = LoadNotifications();

?>