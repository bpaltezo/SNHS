<?php

	function All(){

		$conn = mysqli_connect("localhost", "root", "", "pta");

		$sql = "SELECT * FROM members WHERE deleted != 1";
		$res = $conn->query($sql);

		$contacts = "";

		while($row = $res->fetch_assoc()){

			$contact = str_replace(" ", "", $row["contact"]);
			$contact = str_replace("(", "", $contact);
			$contact = str_replace(")", "", $contact);
			$contact = str_replace("-", "", $contact);

			$contacts .= $contact.",";

		}

		return $contacts;

	}

?>