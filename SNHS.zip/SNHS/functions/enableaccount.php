<?php

	$id = $_GET["id"];
	$conn = mysqli_connect("localhost", "root", "", "pta");
	$sql = "UPDATE users SET status = 0 WHERE id = '$id'";
	$res = $conn->query($sql);

	if($res){
		header("Location: ../users.php");
	}

?>