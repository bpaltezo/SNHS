<?php
	$conn = mysqli_connect("localhost", "root", "", "pta");
	$title = $_POST["_title"];
	$dt = $_POST["_dt"];
	$time = $_POST["_time"];
	$venue = $_POST["_venue"];
	$sql = "INSERT INTO events (title, dt, startat, venue) 
			VALUES ('$title', '$dt', '$time', '$venue')";
	$res = $conn->query($sql);
	if($res) echo "success"; else echo "err";
?>