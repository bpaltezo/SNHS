<?php

	$sql = "SELECT * FROM events WHERE seen = 0 AND deleted = 0";
	$res = $conn->query($sql);

	$eventOutput = "{";

	while($row = $res->fetch_assoc()){
		if(strtotime($row["dt"]) >= strtotime("today")){
			//Future
			$eventOutput .= '"'.$row["dt"].'": 
			{
				number: 1, 
				url: "", 
				event: "'.$row["title"].'",
				date: "'.date("M d Y", strtotime($row["dt"])).'",
				time: "'.$row["startat"].'",
				venue: "'.$row["venue"].'",
			},';
		}else{
			//echo "Past";
		}
	}

	$eventOutput .= "}";

	echo $eventOutput;

?>