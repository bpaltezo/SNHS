<?php

	$conn = mysqli_connect("localhost", "root", "", "pta");
	$id = $_POST["id"];
	$sql = "UPDATE members SET deleted = 1 WHERE id = '$id' ";
	$res = $conn->query($sql);

	if($res){
		echo "success";
	}else{
		echo "err";
	}

?>