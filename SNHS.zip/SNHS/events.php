<?php 
    session_start(); 
    date_default_timezone_set("Asia/Manila");
    $conn = mysqli_connect("localhost", "root", "", "pta");
?>
<!DOCTYPE html>
<html>
<?php

    function TodayEvents(){

        $conn = mysqli_connect("localhost", "root", "", "pta");

        $today = date("Y-m-d");
        $sql = "SELECT * FROM events WHERE dt = '$today' ";
        $res = $conn->query($sql);
            
        $events = array();

        while($row = $res->fetch_assoc()){

            $event = array(
                'id' => $row['id'],
                'title' => $row['title'],
                'dt' => $row['dt'],
                'time' => $row['startat'],
                'venue' => $row['venue'],
                'seen' => $row['seen']
            );

            $events[] = $event;
        }

        return $events;

    }

    $todayevents = TodayEvents();

?>
<head>
    <title>Blank Page | Bootstrap Based Admin Template - Material Design</title>
<?php include "includes/links.php"; ?>
</head>

<body class="theme-teal">

<?php include "includes/header.php"; ?>    

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>EVENTS</h2>
            </div>
            <div class="jsdemo-notification-button">
<?php

    if(count($todayevents) > 0){

        for($i=0;$i<count($todayevents);$i++){

            echo '<button type="button" class="btn btn-primary btn-block waves-effect" data-placement-from="top" data-placement-align="center" data-animate-enter="" data-animate-exit="" data-content="Today is the '.$todayevents[$i]['title'].' event. The event will start at '.$todayevents[$i]['time'].'" data-color-name="bg-deep-orange" style="display:none;"></button>';

        }

    }

?>
            
            
            </div>
        </div>
        <div class="card">
        <div class="header"><h2>CALENDAR VIEW</h2></div>
        <div class="body">
        <div class="container-fluid">
          
        	<div class="container col-lg-12">
      			<!-- Responsive calendar - START -->
    			<div class="responsive-calendar">
        			<div class="controls">
            			<a class="pull-left" data-go="prev"><div class="btn btn-primary">Prev</div></a>
            			<h4><span data-head-year></span> <span data-head-month></span></h4>
            			<a class="pull-right" data-go="next"><div class="btn btn-primary">Next</div></a>
        			</div><hr/>
        			<div class="day-headers">
         			 	<div class="day header">Mon</div>
          				<div class="day header">Tue</div>
          				<div class="day header">Wed</div>
          				<div class="day header">Thu</div>
          				<div class="day header">Fri</div>
          				<div class="day header">Sat</div>
          				<div class="day header">Sun</div>
        			</div>
        			<div class="days" data-group="days"></div>
      			</div>
      			<!-- Responsive calendar - END -->
    		
          	</div>
      	</div>
    	</div>
        </div>

        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="header">
                        <h2>
                            UPCOMING EVENTS
                        </h2>
                        <ul class="header-dropdown m-r--5">
                            <li class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                    <i class="material-icons">more_vert</i>
                                </a>
                                <ul class="dropdown-menu pull-right">
                                   
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="body table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>EVENT</th>
                                    <th>DATE</th>
                                    <th>START TIME</th>
                                    <th>VENUE</th>
                                    <th>DAYS LEFT</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
<?php 

    require_once("includes/functions.php");

    $sql = "SELECT * FROM events WHERE seen=0 AND deleted=0";
    $res = $conn->query($sql);

    while($row = $res->fetch_assoc()){
        echo "<tr><td></td><td>".$row['title']."</td><td>".date("F d Y",strtotime($row['dt']))."</td><td>".$row['startat']."</td><td>".$row['venue']."</td><td>".dateDifference($row['dt'])."</td><td><button class='btn btn-primary' 
            onclick='Notify(`".$row['title']."`,`".date("M d Y", strtotime($row["dt"]))."`,`".$row['startat']."`,`".$row['venue']."`)' title='Notify all members prior to this event'><i class='material-icons'>add_alert</i></button></td></tr>";
    }

?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    
<div class="row clearfix js-sweetalert" style="display: none;">
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
        <button class="dialog-noevent" data-type="noevent"></button>
    </div>
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
        <button class="dialog-newevent" data-type="prompt"></button>
    </div>
</div>

<!-- Small Size -->
<button data-toggle="modal" data-target="#eventmodal" style="display: none;" id="showeventmodal"></button>
<div class="modal fade" id="eventmodal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content modal-col-">
            <div class="modal-header">
                <h4 class="modal-title" id="eventModalTitle">EVENT ON THIS DAY</h4>
            </div>
            <div class="modal-body">
                <p><label>Event: </label> <span class="DisplayEventTitle"></span></p>
                <p><label>Time: </label> <span class="DisplayEventTime"></span></p>
                <p><label>Venue: </label> <span class="DisplayEventVenue"></span></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
            </div>
        </div>
    </div>
</div>

<!-- Small Size -->
<button data-toggle="modal" data-target="#addeventmodal" style="display: none;" id="showaddeventmodal"></button>
<div class="modal fade" id="addeventmodal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content modal-col-">
            <div class="modal-header">
                <h4 class="modal-title" id="eventModalTitle">ADD NEW EVENT</h4>
            </div>
            <div class="modal-body eventContent">
                <br><br>
                <div class="row">
                <div class="col-lg-12">
                <input type="hidden" id="addneweventdate">
                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="text" class="form-control" id="addneweventtitle">
                        <label class="form-label">Event title</label>
                    </div>
                </div>
                </div>
                </div>
                <div class="row">
                <div class="col-lg-2">
                <div class="form-group">
                    <div class="form-line">
                        <input type="text" class="timepicker form-control" placeholder="Start at" data-dtp="dtp_vBvYf" id="addneweventtime">
                    </div>
                </div>
                </div>
                <div class="col-lg-3">
                    <select class="form-control" id="addneweventtimeampm">
                        <option>AM</option>
                        <option>PM</option>
                    </select>
                </div>
                <div class="col-lg-7">
                <div class="form-group form-float">
                    <div class="form-line">
                        <input type="text" class="form-control" id="addneweventvenue">
                        <label class="form-label">Event venue</label>
                    </div>
                </div>
                </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link waves-effect" id="addneweventbtn">SUBMIT</button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CANCEL</button>
            </div>
        </div>
    </div>
</div>

<!-- SMS FEATURE -->
<form method="post" action="https://api.semaphore.co/api/v4/messages" target="_blank" style="display: none;">
    <input type="text" name="apikey" value="742afa72f86bb473bddb4aacc652190d">
    <input type="text" name="number" id="smsnumber">
    <input type="text" name="message" id="smsmessage">
    <input type="submit" id="smsbtn" >
</form>
<!-- SMS FEATURE -->

</section>

</body>
<?php include "includes/footer.php"; ?>
</html>
<script type="text/javascript">
      $(document).ready(function () {

        $(".responsive-calendar").responsiveCalendar({
            time: '<?php date_default_timezone_set("Asia/Manila"); echo date("Y-m"); ?>',
            events: <?php include "functions/loadEvents.php"; ?>,
            onDayClick: function(e){

                var date = new Date();
                var event;
                var a = [this, "year", "month", "day"];
                var y = D(a[0], a[1]);
                var m = (D(a[0], a[2]) < 10) ? "0" + D(a[0], a[2]) : D(a[0], a[2]);
                var d = (D(a[0], a[3]) < 10) ? "0" + D(a[0], a[3]) : D(a[0], a[3]);

                var _date = y + "-" + m + "-" + d;

                function D(c, b){
                    return $(c).data(b);
                }

                function Check(events, d){
                    if(events.hasOwnProperty(d)){
                        event = events[d];
                        return true;
                    }else return false;
                }

                function isValid(a, b, c){

                    var d = "<?php echo date('d') ?>"; //a
                    var m = "<?php echo date('m') ?>"; //m
                    var y = "<?php echo date('Y') ?>"; //y

                    b = parseInt(b);
                    d = parseInt(d);
                    m = parseInt(m);
                    y = parseInt(y);

                    return (a >= d && b >= m && c >= y || a <= d && b > m && c >= y || c > y)
                    ? true : false;
                }

                if(Check(e, _date) && isValid(D(a[0], a[3]), m, y)){

                    console.log(event);
                    $(".DisplayEventTitle").html(event.event);
                    $(".DisplayEventTime").html(event.time);
                    $(".DisplayEventVenue").html(event.venue);
                    $("#showeventmodal").click();
                
                }else if(!Check(e, _date) && isValid(D(a[0], a[3]), m, y)){
                
                    $(".dialog-noevent").attr("data-date", _date);
                    $(".dialog-noevent").click();
                
                }else{
                    console.log("You selected a past date");
                }

            }
        });

        $("#addneweventbtn").on("click", function(){

            function valid(item){
                return (item != "") ? true : false;
            }

            function showSuccessMessage(t,c,l) {
                swal({
                title: t,
                text: c,
                type: "success"
                }, function(isConfirm){
                    if(isConfirm){
                        window.location.href = l;
                    }
                });
            }

            var dt = $("#addneweventdate").val();
            var title = $("#addneweventtitle").val();
            var time = $("#addneweventtime").val() +" "+ $("#addneweventtimeampm").val();
            var venue = $("#addneweventvenue").val();

            if(valid(title) && valid(time) && valid(venue)){

                console.log(title, time, venue);

                $.post("functions/addnewevent.php", 
                {_title: title, _dt: dt, _time: time, _venue: venue},
                function(data, success){
                    console.log(data);
                    if(data == "success"){
                    showSuccessMessage("Success!", "The event was successfully added", "events.php");
                    }
                });

            }else{
                alert("Please complete all required fields");
            }
            
        });

        $(".jsdemo-notification-button button").click();

      });

      function Notify(title, date, time, venue){

        var apikey = "742afa72f86bb473bddb4aacc652190d";
        var recipients = "<?php include 'functions/getAllContacts.php';echo All();?>";
        
        var message = "Good Day! Our " + 
                        title + " event is scheduled at " +
                        date + " " + time + " and will be held at " + venue + ". - SNHS PTA P.R.O.";
        
        var pos = recipients.lastIndexOf(',');
        recipients = recipients.substring(0,pos);
        //console.log(recipients);

        if(recipients != ""){

            document.getElementById("smsnumber").value = recipients;
            document.getElementById("smsmessage").value = message;
            document.getElementById("smsbtn").click();    
          
        }

      }

    </script>
