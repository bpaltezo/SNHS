<?php session_start(); ?>
<?php
    if(!isset($_SESSION["user"])){
        header("Location: login.php");
    }
?>
<!DOCTYPE html>
<html>

<head>
    
    <title>Blank Page | Bootstrap Based Admin Template - Material Design</title>
    <?php include "includes/links.php"; include "includes/functions.php"; ?>

<?php

    if(isset($_POST["account"]) && isset($_POST["id"])){

        $accountupdate = $_POST["option"];

        if($_POST["option"] == "1"){
            $fee = intval($_POST["fee1"]) - intval($_POST["amount"]);
            $newbal = intval($_POST["balance"]) - intval($_POST["amount"]);
            $accountupdate = UpdateAccount($_POST["id"], 1, $fee, $newbal);
            //echo "ID ".$_POST['id']."<br>";
            //echo "FEE ".$fee."<br>";
            //echo "NEW BALANCE ".$newbal;
            //echo $accountupdate;
        }else if($_POST["option"] == "2"){

            $fee = intval($_POST["fee2"]) - intval($_POST["amount"]);
            $newbal = intval($_POST["balance"]) - intval($_POST["amount"]);
            $accountupdate = UpdateAccount($_POST["id"], 2, $fee, $newbal);
        
        }else if($_POST["option"] == "3"){
        
            $fee = intval($_POST["fee3"]) - intval($_POST["amount"]);
            $newbal = intval($_POST["balance"]) - intval($_POST["amount"]);
            $accountupdate = UpdateAccount($_POST["id"], 3, $fee, $newbal);
        
        }
        
    }

    if(isset($_POST["contributions"])){

        if($_POST["updateall"] == "on"){
            $updateall = true;
        }

        $contribupdate = Payments("update", $_POST["fee1"], $_POST["fee2"], $_POST["fee3"], $updateall);

    }

?>

</head>

<body class="theme-teal">

<?php include "includes/header.php"; ?>    

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>FEE MONITORING</h2>
            </div>
        </div>

         <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                MANAGE ACCOUNTS
                            </h2>

                <!-- SECTION FOR INSERTING DIALOG BOXES -->
                            <?php
                                if(isset($accountupdate) && $accountupdate){
                                    echo CreateDialog("success", "Member account has been updated.", "monitoring.php");
                                }

                                if(isset($contribupdate) && $contribupdate){
                                    echo CreateDialog("success", "Payments updated successfully!.", "monitoring.php");
                                }

                            ?>
                    
                <!-- SECTION FOR INSERTING DIALOG BOXES -->
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a class="btn bg-blue btn-circle-lg wave-effect waves-circle waves-float writesms">
                                        <i class="material-icons">mail_outline</i>
                                    </a>
                                    
                                </li>
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle btn bg-teal btn-circle-lg wave-effect waves-circle waves-float" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">print</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a class="table-to-pdf">Export as PDF</a></li>
                                        <li><a class="table-to-xls">Export as Excel</a></li>
                                        <li><a class="table-to-csv">Export as CSV</a></li>
                                        <li><hr></li>
                                        <li><a  class="table-to-copy">Copy</a></li>
                                        <li><a  class="table-to-print">Print</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable datatable-responsive">
                                    <thead>
                                        <tr>
                                        	<th class="check-all">&#10004;</th>
                                            <th>Name</th>
                                            <th>Level</th>
                                            <th>Guardian</th>
                                        	<th>Contact</th>
                                            <th>Status</th>
                                            <th>Balance</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php echo LoadMembers("all", true); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="body" style="display: none;">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Level</th>
                                            <th>Guardian</th>
                                            <th>Address</th>
                                            <th>Contact</th>
                                            <th>Balance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <div class="demo-checkbox">
                                        <?php echo ExportableTable("all"); ?>
                                        </div>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->

            <!-- Basic Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                MANAGE PAYMENTS
                                <small>Basic example without any additional modification classes</small>
                            </h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a data-toggle="modal" data-target="#mp">Update Payments</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th colspan="3"><center>PAYMENTS<center></th>
                                    </tr>
                                    <tr>
                                        <th>MONTLY</th>
                                        <th>HOMEROOM</th>
                                        <th>GENERAL</th>
                                        <th>LAST UPDATED</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php echo Payments("load"); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Table -->

    </section>

<!-- CUSTOM MESSAGE MODAL -->
<a data-toggle="modal" data-target="#cmp" style="display: none;" id="cmpbtn"></a>
<div class="modal fade" id="cmp" tabindex="-1" role="dialog">
   	<div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="largeModalLabel">Compose Message</h4>
            </div>
            <form method="post" target="_blank" action="https://api.semaphore.co/api/v4/messages">
            <div class="modal-body">
            <div class="container-fluid">
            	<div class="row">
                    <input type="hidden" name="apikey" value="742afa72f86bb473bddb4aacc652190d" />
                    <div class="col-lg-12">
            			<div class="input-group">
                            <label>Send to</label>
                            <div class="form-line">
                                <input type="text" name="number" class="form-control cmpnumber" autocomplete="off">
                            </div>
                        </div>
            		</div>
            	</div>
            	<br>
            	<div class="row">
            		<div class="col-lg-12">
            			<div class="input-group">
                            <label>Message</label>
                            <div class="form-line">
                                <textarea class="form-control cmpmessage" 
                                name="message" rows="10" data-toggle="tooltip" data-placement="bottom" title="Select from auto-generated messages. Words with [] needs to be filled up with the appropriate detail. Delete if not necessary">

Good Day! Notice: you have missed to pay your last [PAYMENT] contribution of P[FEE]. We're looking forward for your participation.
-Sual NHS

Good Day! There are total balance of P[BALANCE] you have to comply. Failing to pay this fee, your daughter/son cant enroll for the next year level.
-Sual NHS</textarea>
                            </div>
                        </div>
            			
            		</div>
            	</div>
                <input type="hidden" name="sendername" value="">
            </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-link waves-effect">SEND</button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CANCEL</button>
            </div>
            </form>
        </div>
    </div>
</div>

<!-- Large Size Modal -->
<a data-toggle="modal" data-target="#act" style="display: none;" id="actbtn"></a>
<div class="modal fade" id="act" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div style="float: right;">
                    <button class="btn btn-primary waves-effect notifybutton">
                        <i class="material-icons">add_alert</i> NOTIFY
                    </button>
                    <button class="btn btn-warning waves-effect remindbutton">
                        <i class="material-icons">error_outline</i> REMIND
                    </button>
                </div>
            </div>
            <form id="actform" method="post" action="monitoring.php">
            <div class="modal-body">
            <div class="container-fluid">
                <h2>Account Balance</h2>
                <br><br>
                <div class="row">
                    <div class="col-lg-4">
                        <label>Monthly Contribution</label>
                        <div class="input-group">
                            <span class="input-group-addon">&#8369;</span>
                            <div class="form-line">
                                <input type="number" name="fee1" id="acb1" class="form-control" readonly>
                            </div>
                            <span class="input-group-addon">.00</span>

                        </div>

                    </div>
                    <div class="col-lg-4">
                        <label>Homeroom Contribution</label>
                        <div class="input-group">
                            <span class="input-group-addon">&#8369;</span>
                            <div class="form-line">
                                <input type="number" name="fee2" id="acb2" class="form-control" readonly>
                            </div>
                            <span class="input-group-addon">.00</span>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <label>General Contribution</label>
                        <div class="input-group">
                            <span class="input-group-addon">&#8369;</span>
                            <div class="form-line">
                                <input type="number" name="fee3" id="acb3" class="form-control" readonly>
                            </div>
                            <span class="input-group-addon">.00</span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <h2>Update Balance</h2>
                    <br><br>
                    <div class="col-lg-5">
                        <input type="hidden" name="account">
                        <input type="hidden" id="acid" name="id">
                        <label>Current Balance</label>
                        <div class="input-group">
                            <span class="input-group-addon">&#8369;</span>
                            <div class="form-line">
                                <input type="number" name="balance" id="acbal" class="form-control" readonly>
                            </div>
                            <span class="input-group-addon">.00</span>
                        </div>
                        <br>
                        <label>Name</label>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="material-icons">person</i>
                            </span>
                            <div class="form-line">
                                <input type="text" id="acname" class="form-control" readonly>  
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <label>Payment</label>
                        <select class="form-control" id="actpmt" name="option" required>
                            <option></option>
                            <option value="1">Monthly</option>
                            <option value="2">Homeroom</option>
                            <option value="3">General</option>
                        </select>
                        <br><br><br>
                        <label>Amount</label>
                        <div class="input-group">
                            <span class="input-group-addon">&#8369;</span>
                            <div class="form-line">
                               <input type="number" name="amount" class="form-control actamount" required> 
                            </div>
                            <span class="input-group-addon">.00</span>
                        </div>
                                
                    </div>
                </div>
                <br>
                <div class="demo-checkbox">
                    <input type="checkbox" id="md_checkbox_26" class="filled-in chk-col-light-green" checked="" name="notify" >
                    <label for="md_checkbox_26"> Send payment notification to the member</label>
                </div>
            </div>

            <div class="demo-preloader" style="display: none;">
                <center>
                <div class="preloader pl-size-xl">
                    <div class="spinner-layer">
                        <div class="circle-clipper left">
                            <div class="circle"></div>
                        </div>
                        <div class="circle-clipper right">
                            <div class="circle"></div>
                        </div>
                    </div>
                </div>
                </center>
            </div>
            
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link waves-effect actproceed">PROCEED</button>
                <button type="submit" id="actsmtbtn" style="display:none;"></button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CANCEL</button>
            </div>
            </form>
        </div>
    </div>
</div>

<!-- UPDATE PAYMENTS MODAL -->
<div class="modal fade" id="mp" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="largeModalLabel">
                    Update Payments    
                </h4>
            </div>
            <form method="post" action="monitoring.php">
            <div class="modal-body">
            <div class="container-fluid">
                <div class="row">
                    <br>
                    <div class="col-lg-12">
                        <input type="hidden" name="contributions">
                        <label>Monthly Contribution</label>
                        <div class="input-group">
                            <span class="input-group-addon">&#8369;</span>
                            <div class="form-line">
                                <input type="number" name="fee1" class="form-control" required>
                            </div>
                            <span class="input-group-addon">.00</span>
                        </div>
                        <br>
                        <label>Homeroom Contribution</label>
                        <div class="input-group">
                            <span class="input-group-addon">&#8369;</span>
                            <div class="form-line">
                                <input type="text" name="fee2" class="form-control" required>  
                            </div>
                            <span class="input-group-addon">.00</span>
                        </div>
                        <br>
                        <label>General Contribution</label>
                        <div class="input-group">
                            <span class="input-group-addon">&#8369;</span>
                            <div class="form-line">
                                <input type="text" name="fee3" class="form-control" required>
                            </div>
                            <span class="input-group-addon">.00</span>
                        </div>
                    </div>
                </div>
                <br>
                <div class="demo-checkbox">
                    <input type="checkbox" id="md_checkbox_26" class="filled-in chk-col-light-green" checked name="updateall" >
                    <label for="md_checkbox_26"> Update all accounts for any changes</label>
                </div>
            </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-link waves-effect">PROCEED</button>
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CANCEL</button>
            </div>
            </form>
        </div>
    </div>
</div>

<!-- SMS FEATURE -->
<form method="post" action="https://api.semaphore.co/api/v4/messages" target="_blank" style="display: none;">
    <input type="text" name="apikey" value="742afa72f86bb473bddb4aacc652190d">
    <input type="text" name="number" id="smsnumber">
    <input type="text" name="message" id="smsmessage">
    <input type="submit" id="smsbtn" >
</form>
<!-- SMS FEATURE -->

</body>

<?php include "includes/footer.php"; ?>

</html>


<script type="text/javascript">

    var data = {
        recipient: "",
        recipients: [],
        payments: []
    };

    function format_string(str){
        var result = "";
        for(var x=0;x<str.length;x++){
            if(str[x] == "_") result += " ";
            else result += str[x];
        }
        return result;
    }

    function MakeOR(){
        return Math.random().toString(36).substr(2, 5);
    }

    function SMS(data){
        if(data.type == 1){
            return "Good Day! We have received your payment for the "+data.mode+" contribution of our school, with an OR number #SNHS"+MakeOR()+" to claim this receipt, bring this message with an OR number to the PTA Office. Thank you for the support. - Sual NHS";
        }else if(data.type == 2){
            return "Good Day! Notice: you have missed to pay your payments for monthly P"+data.mode[0]+", homeroom P"+data.mode[1]+" and general contribution of P"+data.mode[2]+". We're looking forward for your participation.  - Sual NHS"
        }else if(data.type == 3){
            return "Good Day! You have an outstanding balance of P"+data.mode+" that you have to comply. Failing to pay this fee, your daughter/son cant enroll for the next year level.   - Sual NHS";
        }
    }

    $(function(){

        $(".chk").on("click", function(){
            if(this.checked){
                data.recipients.push($(this).data("number"));
            }else{

                for(var x=0;x<data.recipients.length;x++){
                    if(data.recipients[x] == $(this).data("number")){
                        data.recipients.splice(x, 1);
                    }
                }

            }
            //console.log(data.recipients);
        });

        $(".check-all").on("click", function(){
            $(".chk").click();  
        });

        $(".mngbtn").on("click", function(){

            if($(this).data("as") == "sms"){
                $(".cmpnumber").val($(this).data("rawdata")[2]);
                $("#cmpbtn").click();
            }else{
                //console.log($(this).data("as"), $(this).data("rawdata"));
                data.recipient = $(this).data("rawdata")[2];
                data.balance = $(this).data("rawdata")[7];
                data.payments.push($(this).data("rawdata")[4]);
                data.payments.push($(this).data("rawdata")[5]);
                data.payments.push($(this).data("rawdata")[6]);

                $("#acid").val($(this).data("rawdata")[8]);
                $("#acb1").val($(this).data("rawdata")[4]);
                $("#acb2").val($(this).data("rawdata")[5]);
                $("#acb3").val($(this).data("rawdata")[6]);
                $("#acbal").val($(this).data("rawdata")[7]);
                $("#acname").val(format_string($(this).data("rawdata")[3]));
                $("#actbtn").click();
            }

        });


        $(".writesms").on("click", function(){

            if(data.recipients.length > 0){

                $(".cmpnumber").val(data.recipients.toString());
                $("#cmpbtn").click();

            }else{
                alert("No recipients! Please check all members that will be recieving the message and try again."); 
            }

        });

        $(".notifybutton").on("click", function(){

            //console.log(data.payments);

            $("#smsnumber").val(data.recipient);
            $("#smsmessage").val(SMS({type: 2, mode: data.payments}));
            $("#smsbtn").click();

        });

        $(".remindbutton").on("click", function(){

            console.log(SMS({type: 3, mode: data.balance}));
            $("#smsnumber").val(data.recipient);
            $("#smsmessage").val(SMS({type: 3, mode: data.balance}));
            $("#smsbtn").click();

        });

        $(".actproceed").on("click", function(){

            function Validate(a, b){
                if(a == "" && b == ""){
                    return false;
                }else if(a == "" && b != ""){
                    return false;
                }else if(a != "" && b == ""){
                    return false;
                }else{
                    return true;
                }
            }

            if($("#md_checkbox_26")[0].checked){
                
                $("#smsnumber").val(data.recipient);
                var option = $("#actpmt").val();
                var fee1 = $("#acb1").val();
                var fee2 = $("#acb2").val();
                var fee3 = $("#acb3").val();
                var sms = "";

                if(option == 1){
                    sms = SMS({type: 1, mode: "Monthly"});
                }else if(option == 2){
                    sms = SMS({type: 1, mode: "Homeroom"});
                }else if(option == 3){
                    sms = SMS({type: 1, mode: "Monthly"});
                }

                //console.log(Validate(option, $(".actamount").val()));

                $("#smsmessage").val(sms);
                
                if(Validate(option, $(".actamount").val())){
                    $("#smsbtn").click();
                }

                $(".demo-preloader").show();

                setInterval(function(){
                    $("#actsmtbtn").click();
                }, 3000);

            }else{
                 $("#actsmtbtn").click();
            }
            
        });

    });

    //console.log(GenerateSMS({type: 1, mode: "Monthly"}));

</script>

